#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <stdio.h>
#include <netinet/in.h>
#include <resolv.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fstream>
#include <string>
#include <iostream>

using namespace std;

int main(int argv, char** argc){

    int host_port= 1101;
    char* host_name="127.0.0.1";

    struct sockaddr_in my_addr;

    char buffer[1024];
    int bytecount;
    int buffer_len=0;

    int _socket;
    int * p_int;
    int err;

    _socket = socket(AF_INET, SOCK_STREAM, 0);
    if(_socket == -1){
        printf("!Cannot Initilize Socket\n");
        exit(0);
    }
    
    p_int = (int*)malloc(sizeof(int));

        

    my_addr.sin_family = AF_INET ;
    my_addr.sin_port = htons(host_port);
    
    memset(&(my_addr.sin_zero), 0, 8);
    my_addr.sin_addr.s_addr = inet_addr(host_name);

    if( connect( _socket, (struct sockaddr*)&my_addr, sizeof(my_addr)) == -1 ){
        if((err = errno) != EINPROGRESS){
            printf("!Cannot Connect\n");
            exit(0);
        }
    }

    //Now lets do the client related stuff

    buffer_len = 1024;

    memset(buffer, '\0', buffer_len);

    printf("Enter some text to send to the server (press enter)\n");
    ////File reading
    string line;
    ifstream myfile ("Test.txt");

    if (myfile.is_open())
    {
        while ( getline(myfile,line) != 0)
        {
            //cout<<"In this loop\n";
            cout<< line;
        }
   //     cout<<"Out of this dloop\n";
        //myfile.close();
   //     cout<<"Here NPE BEfore\n";
    }
    else 
        cout<< "Unable to open file"; 

    char tab2[1024];
    strcpy(tab2, line.c_str());
   // cout<<"HERE\n";
    if( (bytecount=send(_socket, tab2, strlen(tab2),0))== -1){
        printf("!Cannot Send Data\n");
        exit(0);
    }

    cout<<"File Successfully sent!\n";

    // if((bytecount = recv(_socket, buffer, buffer_len, 0))== -1){
    //     printf("!Cannot Recieve Data\n");
    //     exit(0);
    // }
   // cout<<"HERE4\n";
   // printf("Recieved bytes %d\nReceived string \"%s\"\n", bytecount, buffer);
    cout<<"HERE5\n";
    close(_socket);
    
}