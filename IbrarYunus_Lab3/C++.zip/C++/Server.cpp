#include <netinet/in.h>
#include <resolv.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <stdio.h>
#include <fstream>
#include <iostream>
using namespace std;

void* _ServiceRequest(int*);

int main(int argv, char** argc){

    //Initialize Variables
    struct sockaddr_in my_addr;

    //Server_Socket
    int _serverSocket;
    int * p_int ;
    int err;

    //Client Socket
    socklen_t addr_size = 0;
    int* _clientSocket;
    sockaddr_in sadr;

    //Try ti initialize the socket
    _serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if(_serverSocket == -1){
        printf("Error initializing socket %d\n", errno);
        exit(0);
    }
    
    // p_int = (int*)malloc(sizeof(int));
    // *p_int = 1;
        
    // if( (setsockopt(_serverSocket, SOL_SOCKET, SO_REUSEADDR, (char*)p_int, sizeof(int)) == -1 )||
    //     (setsockopt(_serverSocket, SOL_SOCKET, SO_KEEPALIVE, (char*)p_int, sizeof(int)) == -1 ) ){
    //     printf("Error setting options %d\n", errno);
    //     free(p_int);
    //     exit(0);
    // }
    // free(p_int);

    my_addr.sin_family = AF_INET ;
    my_addr.sin_port = htons(1101);
    
    memset(&(my_addr.sin_zero), 0, 8);
    my_addr.sin_addr.s_addr = INADDR_ANY ;
    
    if( bind( _serverSocket, (sockaddr*)&my_addr, sizeof(my_addr)) == -1 ){
            printf("!Cannot Bind Socket\n");
            exit(0);
    }
    if(listen( _serverSocket, 10) == -1 ){
        printf("!Cannot Initialize Listening\n");
        exit(0);
    }


    addr_size = sizeof(sockaddr_in);
    
    while(true){
        printf("C++ Server Initialized\n");
        _clientSocket = (int*)malloc(sizeof(int));
        if((*_clientSocket = accept( _serverSocket, (sockaddr*)&sadr, &addr_size))!= -1){
            printf("-\nConnected to %s\n",inet_ntoa(sadr.sin_addr));
            _ServiceRequest(_clientSocket);
      
        }
        else{
            printf("!Cannot Accept Connection \n");
            exit(0);
        }
    }
}



void* _ServiceRequest(int* _socket){
   // int *_socket = (int*)lp;

    char buffer[1024];
    int buffer_len = 1024;
    int bytecount;

    memset(buffer, 0, buffer_len);
    if((bytecount = recv(*_socket, buffer, buffer_len, 0)) == -1){               //Recieved Here Once
        printf("!Cannot retrieve data\n");
        free(_socket);
        exit(0);
    }

    cout<<buffer;

    if(bytecount > 0)
    {
        while((bytecount = recv(*_socket, buffer, buffer_len, 0)) > 0)
        {
            cout<<buffer;
        }
    }


    strcat(buffer, " SERVER ECHO");
    if((bytecount = send(*_socket, "OK!", 3, 0))== -1){                         //Sent here once
        printf("!Cannot send data\n");
        free(_socket);
        exit(0);
    }
    
    cout<<"\n";
    //printf("Sent bytes %d\n", bytecount);
}